def add_numbers(num1, num2):
    results = num1 + num2
    return f'Sum is: {results}'


def subtract_numbers(num1, num2):
    results = num1 - num2
    return f'Difference is: {results}'


def multiply_numbers(num1, num2):
    results = num1 * num2
    return f'Product is: {results}'


def divide_numbers_float(num1, num2):
    results = num1 / num2
    return f'Quotient Float is: {results}'


def divide_numbers_floor(num1, num2):
    results = num1 // num2
    return f'Quotient Floor is: {results}'


def power_numbers(num1, num2):
    results = num1 ** num2
    return f'Power is: {results}'


def mode_numbers(num1, num2):
    results = num1 % num2
    return f'Mode is: {results}'
